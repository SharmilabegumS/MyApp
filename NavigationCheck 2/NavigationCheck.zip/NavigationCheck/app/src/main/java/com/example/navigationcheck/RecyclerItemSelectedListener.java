package com.example.navigationcheck;


public interface RecyclerItemSelectedListener {

    public void onItemSelected(Contacts contact);
}
